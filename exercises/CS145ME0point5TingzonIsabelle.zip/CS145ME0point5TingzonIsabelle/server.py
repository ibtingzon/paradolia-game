#!/usr/bin/python
#10.40.81.190
import socket
import random

def main():
	responses = ["Hi!", "Mehehehe!", "Hihihih. :>", "Hey sexy thang. ;D", "Wat up homie"]
	host = ''
	port = int(raw_input("Enter port number: "))
	serversocket = socket.socket()
	serversocket.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR, 1)
	serversocket.bind(('', port))

	print 'Server ready...'
	serversocket.listen(5)

	#while True:
	remote_socket, addr = serversocket.accept()
	print str(addr) + ' connected'
	remote_socket.send('Hello')
	
	while True:
		message = remote_socket.recv(1024)
		print message
		#resp = raw_input("Issa: ")
		remote_socket.send(random.choice(responses))
		#remote_socket.send(resp)
		#pass

	remote_socket.close()
	serversocket.close()

if __name__ == '__main__':
	main()

