import socket

class __connection:
    def __init__(self, s):
        self.consocket = s

    def sendMessage(self, msg):
        self.consocket.send(msg)
        #print 'Message sent...'
        return True

    def getMessage(self):
        return self.consocket.recv(1024)
    
