import socket
from connection import __connection

host = raw_input('Enter IP Address: ')
port = int(raw_input('Enter Port Number: '))

clientsocket = socket.socket()
con = __connection(clientsocket)
clientsocket.connect((host,port))

while True:
        message = raw_input("Enter Message: ")
        #clientsocket.send(message)
        con.sendMessage(message)
        response = clientsocket.recv(1024)
        print response

clientsocket.close()
