#!/usr/bin/python
import socket
import random
import time
from connection import __connection

def main():
        responses = ["Hey sexy thang ;D", "Hihihi :'>", "Mehehehe.", "Eowz pfowzzz"]
        host = ''
        port = int(raw_input("Enter port number: "))
        serversocket = socket.socket()
        serversocket.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR, 1)
        serversocket.bind(('', port))

        print 'Server ready...'
        serversocket.listen(5)
        #while True:
        remote_socket, addr = serversocket.accept()
        print str(addr) + 'connected'
        con = __connection(remote_socket)
        #remote_socket.send('Hello')
        con.sendMessage('Hello!')

        #con.sendMessage('end')
        #resp = message[0:len(msgname)] 
        #con.sendMessage(resp)
                
        #remote_socket.send(random.choice(responses)

        while True:
                #message = remote_socket.recv(1024)
                message = con.getMessage()
                print message
                #resp = raw_input("Issa: ")
                #remote_socket.send(resp)
                con.sendMessage(random.choice(responses))
                
        remote_socket.close()
        serversocket.close()

if __name__ == '__main__':
        main()

