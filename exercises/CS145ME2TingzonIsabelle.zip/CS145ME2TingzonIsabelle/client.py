#!/usr/bin/python
import socket
import connection

host = raw_input('Enter IP Address: ')
port = int(raw_input('Enter Port Number: '))

clientsocket = socket.socket()
con = connection.connection(clientsocket)
clientsocket.connect((host,port))

while True:
        message = raw_input("Enter Message: ")
        #clientsocket.send(message)
        con.sendMessage(message)
        #response = clientsocket.recv(1024)
        if message == 'QUIT':
                response = con.getMessage()
                print response
                clientsocket.close()
                break
        response = con.getMessage()
        if message != 'JOKE TIME' and message != 'PICKUP':
                print response
        else:
                while True:
                        print response
                        if response.find('Hahaha') > 0 :
                                #print 'HERE' + response
                                break
                        else:
                                response = con.getMessage()
                
clientsocket.close()
