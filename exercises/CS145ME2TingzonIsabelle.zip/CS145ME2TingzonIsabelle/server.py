#!/usr/bin/python
import socket
import random
import time
import connection

def main():
        responses = ["Hey sexy thang ;D", "Hihihi :'>", "Mehehehe.", "Eowz pfowzzz"]
        host = ''
        port = int(raw_input("Enter port number: "))
        serversocket = socket.socket()
        serversocket.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR, 1)
        serversocket.bind(('', port))

        print 'Server ready...'
        serversocket.listen(5)
        #while True:
        remote_socket, addr = serversocket.accept()
        print str(addr) + 'connected'
        con = connection.connection(remote_socket)
        #remote_socket.send('Hello')
        #con.sendMessage('Hello!')
        
        while True:
                #message = remote_socket.recv(1024)
                message = con.getMessage()
                print message
                #resp = raw_input("Issa: ")
                #remote_socket.send(resp)
                msgname = ('MY NAME IS ')
                if message == 'TIME':
                        resp = 'The time now is ' + time.strftime("%c")
                        con.sendMessage('Server: ' + resp)
                        #con.sendMessage('end')
                elif message[0:len(msgname)] == msgname:
                        name = message[len(msgname):]
                        resp = "Hello, " + name
                        con.sendMessage('Server: ' + resp)
                        #con.sendMessage('end')
                elif message == 'JOKE TIME':
                        con.sendMessage('Server: Anong hayop ang walang pakialam?!')
                        con.sendMessage('Server: Eh di LION! (la yun) \n')
                        con.sendMessage('Server: Hahaha')
                elif message == 'PICKUP':
                        con.sendMessage('Server: B: Drugs ka ba??')
                        con.sendMessage('Server: G: Hindi, bakit? \n')
                        con.sendMessage('Server: B: Naaadik ako sayo eh :">.')
                        con.sendMessage('Hahaha')
                elif message == 'QUIT':
                        con.sendMessage('Goodbye.')
                        remote_socket.close()
                        break
                else:
                        con.sendMessage("Server: I can't understand what you're saying")
                        #con.sendMessage('end')
                #resp = message[0:len(msgname)] 
                #con.sendMessage(resp)
                
                #remote_socket.send(random.choice(responses))
                #con.sendMessage(random.choice(responses))
                #pass

        remote_socket.close()

        serversocket.close()

if __name__ == '__main__':
        main()

