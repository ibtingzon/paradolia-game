#!/usr/bin/python
import socket

host = raw_input('Enter IP Address: ')
port = int(raw_input('Enter Port Number: '))

clientsocket = socket.socket()
clientsocket.connect((host,port))

#message = raw_input("Enter Message: ")
#clientsocket.send(message)
response = clientsocket.recv(1024)
#print message
print response

clientsocket.close()
